-- MySQL dump 10.13  Distrib 5.5.56, for Linux (x86_64)
--
-- Host: tr-rds-syd-prd03.cascuvnqlvjt.ap-southeast-2.rds.amazonaws.com    Database: cloudmall
-- ------------------------------------------------------
-- Server version	5.6.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tea_shipping_cost`
--

DROP TABLE IF EXISTS `tea_shipping_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tea_shipping_cost` (
  `shipping_cost_id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip_code` varchar(45) DEFAULT '',
  `zip_code_from` varchar(45) DEFAULT '',
  `zip_code_to` varchar(45) DEFAULT '',
  `shipping_cost` double(11,2) NOT NULL,
  `pickup` tinyint(4) NOT NULL DEFAULT '0',
  `notes` text,
  `paypal_config_id` int(11) DEFAULT '0',
  `country_id` varchar(20) DEFAULT NULL,
  `state_id` varchar(20) DEFAULT NULL,
  `city_id` varchar(20) DEFAULT NULL,
  `shipper_id` int(11) DEFAULT '0',
  `minimum_price` double(11,2) DEFAULT '0.00',
  `maximum_price` double(11,2) DEFAULT '0.00',
  `minimum_weight` double(11,2) DEFAULT '0.00',
  `maximum_weight` double(11,2) DEFAULT '0.00',
  PRIMARY KEY (`shipping_cost_id`),
  KEY `zip_code_2` (`zip_code_from`),
  KEY `zip_code` (`zip_code_from`,`zip_code_to`),
  KEY `zip_code_3` (`zip_code`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tea_shipping_cost`
--

LOCK TABLES `tea_shipping_cost` WRITE;
/*!40000 ALTER TABLE `tea_shipping_cost` DISABLE KEYS */;
INSERT INTO `tea_shipping_cost` VALUES (3,NULL,NULL,NULL,'','','',0.00,0,'',1,NULL,NULL,NULL,0,0.00,0.00,0.00,0.00),(20,NULL,NULL,NULL,'','','',25.00,0,'',1,NULL,NULL,NULL,0,0.00,0.00,0.00,0.00),(21,'Australia','Victoria',NULL,'','','',17.50,0,'',1,'AU','AU.VI',NULL,0,0.00,0.00,1.00,5000.00),(22,'Australia','Victoria',NULL,'','','',25.00,0,'',1,'AU','AU.VI',NULL,0,0.00,0.00,5001.00,10000.00),(23,'Australia','Victoria',NULL,'','','',30.00,0,'',1,'AU','AU.VI',NULL,0,0.00,0.00,10001.00,15000.00),(24,'Australia','Queensland',NULL,'','4000','4310',0.00,0,'',1,'AU','AU.QL',NULL,0,500.00,1000000.00,0.00,0.00),(25,'Australia','Queensland',NULL,'','4000','4310',10.00,0,'',1,'AU','AU.QL',NULL,0,0.01,499.99,0.00,0.00),(58,'Australia','Queensland',NULL,'','4557','4558',0.00,0,'',1,'AU','AU.QL',NULL,0,500.00,20000.00,0.00,0.00),(59,'Australia','New South Wales',NULL,'','2300','2316',15.00,0,'',1,'AU','AU.NS',NULL,0,250.00,400.00,0.00,0.00),(60,'Australia','Queensland',NULL,'','','',20.50,0,'',1,'AU','AU.QL',NULL,0,401.00,700.00,0.00,0.00),(94,'Australia','South Australia',NULL,'','','',0.00,0,'',1,'AU','AU.SA',NULL,0,750.00,0.00,0.00,0.00),(119,'United States of America',NULL,NULL,'','','',20.20,0,'',1,'US',NULL,NULL,0,0.00,0.00,0.01,500.00),(120,'United States of America',NULL,NULL,'','','',33.25,0,'',1,'US',NULL,NULL,0,0.00,0.00,501.00,1000.00),(145,'United States of America',NULL,NULL,'','','',450.00,0,'',1,'US',NULL,NULL,0,0.00,0.00,0.01,20000.00),(146,'Canada',NULL,NULL,'','','',450.00,0,'',1,'CA',NULL,NULL,0,0.00,0.00,0.01,20000.00),(163,'Australia','New South Wales',NULL,'','2315','2316',15.00,0,'',1,'AU','AU.NS',NULL,0,0.00,0.00,0.00,10000.00),(164,'Australia','New South Wales',NULL,'','2289','2290',0.00,0,'',1,'AU','AU.NS',NULL,0,500.00,0.00,0.00,0.00),(188,'Australia','New South Wales',NULL,'','2448','2449',0.00,0,'',1,'AU','AU.NS',NULL,0,400.00,0.00,0.00,0.00),(189,'Australia','Victoria',NULL,'','3165','3197',20.00,0,'',1,'AU','AU.VI',NULL,0,0.00,0.00,0.00,5000.00),(190,'Australia','',NULL,'','','',0.00,0,'',1,'AU','',NULL,0,1.00,0.00,0.00,5000.00),(192,'Australia','Victoria',NULL,'','3165','3166',0.00,0,'',1,'AU','AU.VI',NULL,0,250.00,0.00,0.00,0.00),(193,'Australia','New South Wales',NULL,'','2020','2021',17.50,0,'',1,'AU','AU.NS',NULL,0,250.00,0.00,0.00,0.00),(194,'Canada',NULL,NULL,'','','',0.00,0,'',1,'CA',NULL,NULL,0,199.99,0.00,0.00,0.00),(195,'Singapore',NULL,NULL,'','','',0.00,0,'',1,'SG',NULL,NULL,0,199.99,0.00,0.00,0.00),(196,'Canada',NULL,NULL,'','','',57.00,0,'',1,'CA',NULL,NULL,0,1.00,199.98,0.00,0.00),(197,'Singapore',NULL,NULL,'','','',60.00,0,'',1,'SG',NULL,NULL,0,1.00,199.98,0.00,0.00),(198,'United States of America',NULL,NULL,'','','',60.00,0,'',1,'US',NULL,NULL,0,1.00,199.98,0.00,0.00);
/*!40000 ALTER TABLE `tea_shipping_cost` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-27 12:23:53
